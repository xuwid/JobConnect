package application.user;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;

public class ProfilePage {
    private final BorderPane dashboardRoot;
    private boolean isEditable = false; // Flag to track the editable state

    public ProfilePage(BorderPane dashboardRoot) {
        this.dashboardRoot = dashboardRoot;
    }

    /**
     * Returns the interface for the Profile Page.
     */
    public VBox getView() {
        // Main layout for the Profile Page
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setStyle("-fx-background-color: #f4f6f7;"); // Matching the Logs Page theme

        // Title for the Profile Page
        Label titleLabel = new Label("Your Profile");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #34495e;");

        // ID Field (always non-editable)
        TextField idField = new TextField("12345"); // Simulated user ID
        idField.setEditable(false);
        styleTextField(idField);

        // Name and Email fields (initially non-editable)
        TextField nameField = new TextField("Enter your name");
        styleTextField(nameField);

        TextField emailField = new TextField("Enter your email");
        styleTextField(emailField);

        // Toggle Edit Mode button
        Button toggleEditButton = new Button("Edit Profile");
        styleButton(toggleEditButton, "#3498db"); // Matching the Logs Page button color
        toggleEditButton.setOnAction(e -> {
            isEditable = !isEditable; // Toggle edit state
            toggleFields(nameField, emailField);
            toggleEditButton.setText(isEditable ? "Save Changes" : "Edit Profile");
        });

        // Back to Dashboard button
//        Button backButton = new Button("Back to Dashboard");
//        styleButton(backButton, "#e74c3c"); // Red back button for consistency
//        backButton.setOnAction(e -> returnToDashboard());

        // Adding elements to the layout
        layout.getChildren().addAll(titleLabel, new Label("User ID:"), idField, nameField, emailField, toggleEditButton);
        return layout;
    }

    /**
     * Toggles the fields between editable and non-editable.
     */
    private void toggleFields(TextField nameField, TextField emailField) {
        nameField.setEditable(isEditable);
        emailField.setEditable(isEditable);
        nameField.setStyle(isEditable ? "-fx-background-color: #ffffff;" : "-fx-background-color: #ecf0f1;");
        emailField.setStyle(isEditable ? "-fx-background-color: #ffffff;" : "-fx-background-color: #ecf0f1;");
    }

    /**
     * Styles a text field consistently.
     */
    private void styleTextField(TextField textField) {
        textField.setEditable(false); // Default non-editable
        textField.setStyle("-fx-font-size: 16px; -fx-text-fill: #34495e; -fx-background-color: #ecf0f1; -fx-border-color: #dcdcdc; -fx-border-radius: 5;");
        textField.setPrefWidth(400);
    }

    /**
     * Styles a button with a given background color.
     */
    private void styleButton(Button button, String color) {
        button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20; -fx-border-radius: 5;");
        button.setPrefWidth(250);
    }

    /**
     * Returns the user to the Dashboard.
     */
//    private void returnToDashboard() {
//        // Welcome message content
//        Label welcomeLabel = new Label("Welcome to Job Connect Dashboard!");
//        welcomeLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #34495e;");
//
//        VBox welcomeContent = new VBox(welcomeLabel);
//        welcomeContent.setAlignment(Pos.CENTER);
//        welcomeContent.setPadding(new Insets(30));
//        welcomeContent.setStyle("-fx-background-color: #f4f6f7;");
//
//        dashboardRoot.setCenter(welcomeContent);
//    }
}
