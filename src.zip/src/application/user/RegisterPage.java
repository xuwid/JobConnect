package application.user;

import application.Dashboard;
import application.SceneManager;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class RegisterPage {
    private final SceneManager sceneManager;

    public RegisterPage(SceneManager sceneManager) {
        this.sceneManager = sceneManager;
    }

    public Scene getScene() {
        // Main container with centering
        VBox root = new VBox();
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(50));
        root.setStyle("-fx-background-color: #f4f6f7;"); // Consistent background color

        // Card container for form
        VBox card = new VBox(20);
        card.setPadding(new Insets(30));
        card.setAlignment(Pos.CENTER);
        card.setStyle("-fx-background-color: #ffffff; -fx-background-radius: 10; -fx-border-radius: 10; -fx-border-color: #bdc3c7; -fx-border-width: 1;");

        // Shadow effect
        card.setEffect(new DropShadow(10, Color.GRAY));

        // Header section
        Text title = new Text("Create an Account");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        title.setFill(Color.web("#34495e")); // Dark gray for title

        Text subtitle = new Text("Join our platform to connect with job opportunities.");
        subtitle.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        subtitle.setFill(Color.GRAY);

        // Form inputs
        TextField usernameField = createStyledTextField("Enter your username");
        TextField emailField = createStyledTextField("Enter your email");
        PasswordField passwordField = createStyledPasswordField("Enter your password");

        ComboBox<String> roleComboBox = new ComboBox<>();
        roleComboBox.getItems().addAll("Job Seeker", "Job Poster", "Admin");
        roleComboBox.setPromptText("Select Role");
        roleComboBox.setPrefHeight(40);
        roleComboBox.setStyle("-fx-font-size: 14px; -fx-border-color: #bdc3c7; -fx-border-radius: 5; -fx-background-radius: 5;");

        // Buttons
        Button registerButton = createStyledButton("Register", "#27ae60");
        registerButton.setOnAction(e -> {
            String username = usernameField.getText();
            String email = emailField.getText();
            String password = passwordField.getText();
            String role = roleComboBox.getValue();

            // Validate input
            if (username.isEmpty() || email.isEmpty() || password.isEmpty() || role == null) {
                System.out.println("Please fill all fields and select a role.");
            } else {
                System.out.println("User Registered as " + role + "!");

                // Redirect to appropriate dashboard
                Dashboard dashboard = new Dashboard(sceneManager, role);
                sceneManager.addScene("Dashboard", dashboard.getScene());
                sceneManager.switchTo("Dashboard");
            }
        });

        Button backButton = createStyledButton("Back to Login", "#e74c3c");
        backButton.setOnAction(e -> sceneManager.switchTo("LoginPage"));

        // Arrange components
        card.getChildren().addAll(title, subtitle, usernameField, emailField, passwordField, roleComboBox, registerButton, backButton);
        root.getChildren().add(card);

        return new Scene(root, 500, 600);
    }

    /**
     * Creates a styled text field with a placeholder.
     */
    private TextField createStyledTextField(String placeholder) {
        TextField textField = new TextField();
        textField.setPromptText(placeholder);
        textField.setPrefHeight(40);
        textField.setStyle("-fx-font-size: 14px; -fx-border-color: #bdc3c7; -fx-border-radius: 5; -fx-background-radius: 5;");
        return textField;
    }

    /**
     * Creates a styled password field with a placeholder.
     */
    private PasswordField createStyledPasswordField(String placeholder) {
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText(placeholder);
        passwordField.setPrefHeight(40);
        passwordField.setStyle("-fx-font-size: 14px; -fx-border-color: #bdc3c7; -fx-border-radius: 5; -fx-background-radius: 5;");
        return passwordField;
    }

    /**
     * Creates a styled button with the given text and background color.
     */
    private Button createStyledButton(String text, String color) {
        Button button = new Button(text);
        button.setPrefWidth(200);
        button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20; -fx-border-radius: 5; -fx-background-radius: 5;");
        return button;
    }
}
