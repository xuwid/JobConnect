package application;

import application.jobs.DeleteJobPage;
import application.jobs.EditJobPage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class JobManagementPage {
    private final SceneManager sceneManager;
    private final BorderPane dashboardRoot;

    public JobManagementPage(SceneManager sceneManager, BorderPane dashboardRoot) {
        this.sceneManager = sceneManager;
        this.dashboardRoot = dashboardRoot;
    }

    public ScrollPane getView() {
        // Main layout for the page
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.TOP_CENTER);

        // Title Label
        Label titleLabel = new Label("Manage Your Jobs");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        titleLabel.setStyle("-fx-text-fill: #34495e;");

        // Edit Job Button
        Button editJobButton = new Button("Edit Job Listings");
        editJobButton.setStyle("-fx-background-color: #2c3e50; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10;");
        editJobButton.setOnAction(e -> {
            EditJobPage editJobPage = new EditJobPage(sceneManager, dashboardRoot);
            dashboardRoot.setCenter(editJobPage.getView());
        });

        // Delete Job Button
        Button deleteJobButton = new Button("Delete Job Listings");
        deleteJobButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10;");
        deleteJobButton.setOnAction(e -> {
			DeleteJobPage deleteJobPage = new DeleteJobPage(sceneManager,dashboardRoot);
			dashboardRoot.setCenter(deleteJobPage.getView());
        });

        // Add components to layout
        layout.getChildren().addAll(titleLabel, editJobButton, deleteJobButton);

        // Wrap layout in a scroll pane
        ScrollPane scrollPane = new ScrollPane(layout);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: #ecf0f1;");
        scrollPane.setPadding(new Insets(10));

        return scrollPane;
    }
}
