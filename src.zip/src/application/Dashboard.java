package application;

import application.admin.ManageJobsPage;
import application.admin.ManageUsersPage;
import application.admin.SystemLogsPage;
import application.jobs.JobListingsPage;
import application.jobs.PostJobPage;
import application.shared.NotificationsPage;
import application.shared.UserSupportPage;
import application.user.ProfilePage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class Dashboard {
    private final SceneManager sceneManager;
    private final String userType;
    private final BorderPane root;

    public Dashboard(SceneManager sceneManager, String userType) {
        this.sceneManager = sceneManager;
        this.userType = userType;
        this.root = new BorderPane();
    }

    public Scene getScene() {
        root.setPadding(new Insets(20));

        // Header Section
        HBox header = createHeader();
        root.setTop(header);

        // Sidebar
        VBox sidebar = createSidebar();
        root.setLeft(sidebar);

        // Content based on user type
        VBox dashboardOverview = createDashboardOverview();
        root.setCenter(dashboardOverview);

        // Footer
        HBox footer = createFooter();
        root.setBottom(footer);

        Scene scene = new Scene(root, 1000, 600);
        scene.getStylesheets().add(getClass().getResource("dashboard.css").toExternalForm());
        return scene;
    }

    /**
     * Creates the header with a right-aligned title.
     */
    private HBox createHeader() {
        HBox header = new HBox();
        header.setPadding(new Insets(10, 20, 10, 20));
        header.setAlignment(Pos.CENTER_RIGHT); // Align the label to the right
        header.setStyle("-fx-background-color: #34495e;");

        Label headerLabel = new Label("Job Connect Dashboard");
        headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        headerLabel.setTextFill(Color.WHITE);

        header.getChildren().add(headerLabel);
        return header;
    }

    /**
     * Creates the sidebar with navigation buttons and styles.
     */
    private VBox createSidebar() {
        VBox sidebar = new VBox(20);
        sidebar.setPadding(new Insets(20));
        sidebar.setAlignment(Pos.TOP_LEFT);
        sidebar.setStyle("-fx-background-color: #2c3e50;");

        // Admin-specific navigation
        if (userType.equals("Admin")) {
            sidebar.getChildren().addAll(
                    createNavigationButton("Manage Users", () -> loadPage(new ManageUsersPage(sceneManager, root).getView())),
                    createNavigationButton("Manage Jobs", () -> loadPage(new ManageJobsPage(sceneManager, root).getView())),
                    createNavigationButton("View Logs", () -> loadPage(new SystemLogsPage(sceneManager, root).getView()))
            );
        }

        // User-specific navigation
        if (userType.equals("Job Seeker")) {
            sidebar.getChildren().addAll(
                    createNavigationButton("Browse Jobs", () -> loadPage(new JobListingsPage(sceneManager, root).getView()))
            );
        } else if (userType.equals("Job Poster")) {
            sidebar.getChildren().addAll(
                    createNavigationButton("Post Job", () -> loadPage(new PostJobPage(sceneManager, root).getView())),
                    createNavigationButton("Manage Jobs", () -> loadPage(new JobManagementPage(sceneManager, root).getView())),
                    createNavigationButton("Manage Applications", () -> loadPage(new JobSelectionPage(root).getView()))
            );
        }

        // Shared navigation
        if (!userType.equals("Admin")) { // Exclude Notifications and User Support for Admin
            sidebar.getChildren().addAll(
                    createNavigationButton("Notifications", () -> loadPage(new NotificationsPage(root).getView())),
                    createNavigationButton("User Support", () -> loadPage(new UserSupportPage(root).getView()))
            );
        }

        sidebar.getChildren().addAll(
                createNavigationButton("Profile", () -> loadPage(new ProfilePage(root).getView())),
                createNavigationButton("Logout", () -> sceneManager.switchTo("LoginPage"))
        );

        return sidebar;
    }

    /**
     * Creates the dashboard overview tailored to the user type.
     */
    private VBox createDashboardOverview() {
        VBox overview = new VBox(20);
        overview.setPadding(new Insets(20));
        overview.setAlignment(Pos.TOP_CENTER);

        Label title = new Label("Welcome, " + userType + "!");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 22));
        title.setTextFill(Color.DARKBLUE);

        if (userType.equals("Admin")) {
            Label statsHeader = new Label("Admin Dashboard Overview");
            statsHeader.setFont(Font.font("Arial", FontWeight.BOLD, 18));

            HBox stats = new HBox(20);
            stats.setAlignment(Pos.CENTER);
            stats.getChildren().addAll(
                    createStatBox("Total Users", "1234"),
                    createStatBox("Jobs Posted", "567"),
                    createStatBox("Active Admins", "3")
            );

            overview.getChildren().addAll(title, statsHeader, stats);
        } else if (userType.equals("Job Seeker")) {
            Label statsHeader = new Label("Your Dashboard Overview");
            statsHeader.setFont(Font.font("Arial", FontWeight.BOLD, 18));

            HBox stats = new HBox(20);
            stats.setAlignment(Pos.CENTER);
            stats.getChildren().addAll(
                    createStatBox("Jobs Applied", "15"),
                    createStatBox("Interviews Scheduled", "3"),
                    createStatBox("Saved Jobs", "8")
            );

            overview.getChildren().addAll(title, statsHeader, stats);
        } else if (userType.equals("Job Poster")) {
            Label statsHeader = new Label("Your Dashboard Overview");
            statsHeader.setFont(Font.font("Arial", FontWeight.BOLD, 18));

            HBox stats = new HBox(20);
            stats.setAlignment(Pos.CENTER);
            stats.getChildren().addAll(
                    createStatBox("Jobs Posted", "10"),
                    createStatBox("Applications Received", "42"),
                    createStatBox("Interviews Scheduled", "5")
            );

            overview.getChildren().addAll(title, statsHeader, stats);
        }

        return overview;
    }

    /**
     * Creates a small statistics box for quick stats display.
     */
    private VBox createStatBox(String label, String value) {
        VBox statBox = new VBox(5);
        statBox.setAlignment(Pos.CENTER);
        statBox.setPadding(new Insets(10));
        statBox.setStyle("-fx-background-color: #ecf0f1; -fx-border-color: #bdc3c7; -fx-border-radius: 5; -fx-background-radius: 5;");

        Label statValue = new Label(value);
        statValue.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        statValue.setTextFill(Color.DARKBLUE);

        Label statLabel = new Label(label);
        statLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));

        statBox.getChildren().addAll(statValue, statLabel);
        return statBox;
    }

    /**
     * Creates the footer with additional links.
     */
    private HBox createFooter() {
        HBox footer = new HBox(10);
        footer.setAlignment(Pos.CENTER);
        footer.setPadding(new Insets(10));
        footer.setStyle("-fx-background-color: #34495e;");

        Label privacyPolicy = new Label("Privacy Policy");
        privacyPolicy.setTextFill(Color.WHITE);

        Label terms = new Label("Terms of Service");
        terms.setTextFill(Color.WHITE);

        footer.getChildren().addAll(privacyPolicy, new Label("|"), terms);
        return footer;
    }

    /**
     * Creates a styled navigation button and sets its action.
     */
    private Button createNavigationButton(String text, Runnable action) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: #34495e; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10;");
        button.setOnAction(e -> action.run());
        button.setMaxWidth(Double.MAX_VALUE);
        return button;
    }

    /**
     * Dynamically loads a page into the center of the dashboard.
     */
    private void loadPage(Node content) {
        root.setCenter(content);
    }
}
