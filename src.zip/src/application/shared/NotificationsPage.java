package application.shared;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.util.ArrayList;
import java.util.List;

public class NotificationsPage {
    private final BorderPane dashboardRoot;
    private VBox notificationListContainer; // Container for notification cards
    private List<String> notifications;    // Simulated notification data

    public NotificationsPage(BorderPane dashboardRoot) {
        this.dashboardRoot = dashboardRoot;

        // Initialize notifications (simulated data)
        this.notifications = new ArrayList<>();
        notifications.add("New job match found: Software Engineer at TechCorp");
        notifications.add("Your application for Software Developer is under review.");
        notifications.add("New message from John Doe regarding Job ID 102.");
        notifications.add("System maintenance scheduled for tomorrow at 2 PM.");
    }

    /**
     * Returns the Notifications Page layout.
     */
    public VBox getView() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setStyle("-fx-background-color: #ecf0f1;");

        // Title
        Label titleLabel = new Label("Notifications");
        titleLabel.setFont(Font.font("Arial", 24));
        titleLabel.setTextFill(Color.DARKBLUE);

        // Search Bar
        HBox searchBar = createSearchBar();

        // Scrollable notifications list
        ScrollPane scrollPane = createScrollableNotificationsList();

        // Add all elements to layout
        layout.getChildren().addAll(titleLabel, searchBar, scrollPane);
        return layout;
    }

    /**
     * Creates a search bar with search and delete functionality.
     */
    private HBox createSearchBar() {
        HBox searchBar = new HBox(10);
        searchBar.setAlignment(Pos.CENTER);
        searchBar.setPadding(new Insets(10));
        searchBar.setStyle("-fx-background-color: #ffffff; -fx-background-radius: 10;");

        // Search Field
        TextField searchField = new TextField();
        searchField.setPromptText("Search notifications...");
        searchField.setPrefWidth(300);

        // Search Button
        Button searchButton = new Button("Search");
        searchButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");
        searchButton.setOnAction(e -> performSearch(searchField.getText()));

        // Delete All Button
        Button deleteAllButton = new Button("Delete All");
        deleteAllButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        deleteAllButton.setOnAction(e -> deleteAllNotifications());

        searchBar.getChildren().addAll(searchField, searchButton, deleteAllButton);
        return searchBar;
    }

    /**
     * Creates a scrollable pane for notifications.
     */
    private ScrollPane createScrollableNotificationsList() {
        notificationListContainer = new VBox(10);
        notificationListContainer.setAlignment(Pos.TOP_CENTER);
        notificationListContainer.setPadding(new Insets(10));

        // Populate notifications initially
        updateNotificationList(notifications);

        ScrollPane scrollPane = new ScrollPane(notificationListContainer);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent;");
        return scrollPane;
    }

    /**
     * Updates the notification list dynamically.
     */
    private void updateNotificationList(List<String> filteredNotifications) {
        notificationListContainer.getChildren().clear();

        if (filteredNotifications.isEmpty()) {
            Label noResultsLabel = new Label("No notifications found.");
            noResultsLabel.setTextFill(Color.RED);
            notificationListContainer.getChildren().add(noResultsLabel);
        } else {
            for (String notification : filteredNotifications) {
                VBox notificationCard = createNotificationCard(notification);
                notificationListContainer.getChildren().add(notificationCard);
            }
        }
    }

    /**
     * Performs a search and updates the notifications list.
     */
    private void performSearch(String query) {
        if (query == null || query.trim().isEmpty()) {
            updateNotificationList(notifications); // Show all notifications if search is empty
            return;
        }

        List<String> filteredNotifications = notifications.stream()
                .filter(notification -> notification.toLowerCase().contains(query.toLowerCase()))
                .toList();

        updateNotificationList(filteredNotifications);
    }

    /**
     * Deletes all notifications.
     */
    private void deleteAllNotifications() {
        notifications.clear();
        updateNotificationList(notifications);
        System.out.println("All notifications have been deleted.");
    }

    /**
     * Deletes a single notification.
     */
    private void deleteNotification(String notification) {
        notifications.remove(notification);
        updateNotificationList(notifications);
        System.out.println("Notification deleted: " + notification);
    }

    /**
     * Creates a styled notification card with a delete button.
     */
    private VBox createNotificationCard(String notificationText) {
        VBox notificationCard = new VBox(10);
        notificationCard.setPadding(new Insets(15));
        notificationCard.setAlignment(Pos.CENTER_LEFT);
        notificationCard.setStyle("-fx-background-color: #ffffff; -fx-border-color: #bdc3c7; -fx-border-radius: 10; -fx-background-radius: 10;");

        Label notificationLabel = new Label(notificationText);
        notificationLabel.setFont(Font.font("Arial", 16));
        notificationLabel.setTextFill(Color.web("#34495e"));

        Button deleteButton = new Button("Delete");
        deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        deleteButton.setOnAction(e -> deleteNotification(notificationText));

        HBox cardFooter = new HBox(deleteButton);
        cardFooter.setAlignment(Pos.CENTER_RIGHT);

        notificationCard.getChildren().addAll(notificationLabel, cardFooter);
        return notificationCard;
    }

    /**
     * Returns the user to the Dashboard.
     */
    private void returnToDashboard() {
        // Welcome message content
        Label welcomeLabel = new Label("Welcome to Job Connect Dashboard!");
        welcomeLabel.setFont(Font.font("Arial", 20));
        welcomeLabel.setTextFill(Color.DARKBLUE);

        VBox welcomeContent = new VBox(welcomeLabel);
        welcomeContent.setAlignment(Pos.CENTER);
        welcomeContent.setPadding(new Insets(30));
        welcomeContent.setStyle("-fx-background-color: #ecf0f1;");

        dashboardRoot.setCenter(welcomeContent);
    }
}
