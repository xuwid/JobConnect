package application.shared;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.scene.layout.BorderPane;

public class UserSupportPage {
    private final BorderPane dashboardRoot;

    public UserSupportPage(BorderPane dashboardRoot) {
        this.dashboardRoot = dashboardRoot;
    }

    public VBox getView() {
        // Main layout for the User Support page
        VBox layout = new VBox(20);
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setPadding(new Insets(20));
        layout.setStyle("-fx-background-color: #f4f6f7;");

        // Title for the User Support page
        Label titleLabel = new Label("User Support");
        titleLabel.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #34495e; -fx-padding: 0 0 20 0;");

        // Subtitle with instructions
        Label subtitleLabel = new Label("We are here to help! Please describe your issue or query below.");
        subtitleLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #7f8c8d; -fx-padding: 0 0 20 0;");

        // Create the query input area with card-like styling
        VBox queryCard = createQueryCard();

        // Create the Submit Query button
        Button submitQueryButton = createStyledButton("Submit Query", "#2980b9");
        submitQueryButton.setOnAction(e -> {
            String queryText = ((TextArea) queryCard.getChildren().get(0)).getText();
            if (queryText.isEmpty()) {
                System.out.println("Query cannot be empty!");
            } else {
                System.out.println("Query submitted: " + queryText);
                showConfirmationDialog("Your query has been submitted successfully. Our support team will get back to you soon!");
            }
        });

        

        // Adding all elements to the layout
        layout.getChildren().addAll(titleLabel, subtitleLabel, queryCard, submitQueryButton);

        return layout;
    }

    // Helper method to create the query input card
    private VBox createQueryCard() {
        // Create a VBox for the card
        VBox queryCard = new VBox(10);
        queryCard.setAlignment(Pos.CENTER);
        queryCard.setPadding(new Insets(15));
        queryCard.setStyle("-fx-background-color: white; -fx-border-radius: 10px; -fx-border-color: #bdc3c7; -fx-background-radius: 10px; -fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.1), 10, 0, 2, 2);");

        // TextArea for the user query
        TextArea queryArea = new TextArea();
        queryArea.setPromptText("Describe your issue or query...");
        queryArea.setPrefRowCount(5);
        queryArea.setStyle("-fx-font-size: 14px; -fx-text-fill: #34495e; -fx-border-color: #bdc3c7; -fx-border-radius: 8px; -fx-padding: 10; -fx-background-color: #fdfdfd;");

        queryCard.getChildren().add(queryArea);

        return queryCard;
    }

    // Helper method to create styled buttons
    private Button createStyledButton(String text, String backgroundColor) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: " + backgroundColor + "; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 20; -fx-border-radius: 8px; -fx-background-radius: 8px;");
        button.setPrefWidth(200);
        return button;
    }

    // Helper method to display a confirmation dialog
    private void showConfirmationDialog(String message) {
        VBox dialogLayout = new VBox(10);
        dialogLayout.setAlignment(Pos.CENTER);
        dialogLayout.setPadding(new Insets(20));
        dialogLayout.setStyle("-fx-background-color: #ecf0f1; -fx-border-color: #bdc3c7; -fx-border-radius: 10px; -fx-background-radius: 10px;");

        Label messageLabel = new Label(message);
        messageLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #2c3e50; -fx-padding: 10 0;");

        Button okButton = createStyledButton("OK", "#27ae60");
        okButton.setOnAction(e -> dashboardRoot.setCenter(getView()));

        dialogLayout.getChildren().addAll(messageLabel, okButton);

        dashboardRoot.setCenter(dialogLayout);
    }
}
