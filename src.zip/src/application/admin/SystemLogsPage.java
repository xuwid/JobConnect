package application.admin;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import application.SceneManager;

public class SystemLogsPage {
    private final SceneManager sceneManager;
    private final BorderPane root;
    private TextArea logsArea; // Display area for logs
    private List<String> logs; // Simulated log data

    public SystemLogsPage(SceneManager sceneManager, BorderPane root) {
        this.sceneManager = sceneManager;
        this.root = root;

        // Initialize logs (simulated data)
        this.logs = new ArrayList<>();
        logs.add("[2024-11-20 10:00:01] System started.");
        logs.add("[2024-11-20 10:05:45] Admin logged in.");
        logs.add("[2024-11-20 10:10:15] Job posted by John Doe.");
        logs.add("[2024-11-20 10:15:30] User Jane Smith applied for Job ID 2.");
    }

    /**
     * Returns the interface for viewing system logs.
     */
    public VBox getView() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);

        // Title
        Label title = new Label("System Logs");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        // Search Bar
        HBox searchBar = createSearchBar();

        // Logs Display Area
        logsArea = new TextArea();
        logsArea.setEditable(false);
        logsArea.setPrefHeight(400);
        logsArea.setPrefWidth(600);
        logsArea.setStyle("-fx-font-family: monospace;");

        // Populate logs initially
        updateLogsArea(logs);

        // Button to Download Logs
        Button downloadButton = new Button("Download Logs");
        downloadButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");
        downloadButton.setOnAction(e -> downloadLogs());

        layout.getChildren().addAll(title, searchBar, logsArea, downloadButton);
        return layout;
    }

    /**
     * Creates a search bar with search and filter options.
     */
    private HBox createSearchBar() {
        HBox searchBar = new HBox(10);
        searchBar.setAlignment(Pos.CENTER);
        searchBar.setPadding(new Insets(10));
        searchBar.setStyle("-fx-background-color: #ffffff; -fx-background-radius: 10;");

        // Search Field
        TextField searchField = new TextField();
        searchField.setPromptText("Search logs by keywords");
        searchField.setPrefWidth(300);

        // Filter by Date
        DatePicker datePicker = new DatePicker();
        datePicker.setPromptText("Filter by Date");

        // Search Button
        Button searchButton = new Button("Search");
        searchButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");
        searchButton.setOnAction(e -> performSearch(searchField.getText(), datePicker.getValue() != null ? datePicker.getValue().toString() : null));

        searchBar.getChildren().addAll(searchField, datePicker, searchButton);
        return searchBar;
    }

    /**
     * Updates the logs display area.
     */
    private void updateLogsArea(List<String> filteredLogs) {
        logsArea.clear();
        if (filteredLogs.isEmpty()) {
            logsArea.setText("No logs found for the specified criteria.");
        } else {
            logsArea.setText(String.join("\n", filteredLogs));
        }
    }

    /**
     * Filters logs based on a keyword and/or date.
     */
    private void performSearch(String keyword, String date) {
        List<String> filteredLogs = logs;

        if (keyword != null && !keyword.trim().isEmpty()) {
            filteredLogs = filteredLogs.stream()
                    .filter(log -> log.toLowerCase().contains(keyword.toLowerCase()))
                    .collect(Collectors.toList());
        }

        if (date != null) {
            filteredLogs = filteredLogs.stream()
                    .filter(log -> log.contains(date))
                    .collect(Collectors.toList());
        }

        updateLogsArea(filteredLogs);
    }

    /**
     * Allows the user to download the logs as a text file.
     */
    private void downloadLogs() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Logs");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        File file = fileChooser.showSaveDialog(root.getScene().getWindow());

        if (file != null) {
            try (FileWriter writer = new FileWriter(file)) {
                writer.write(logsArea.getText());
                System.out.println("Logs saved to: " + file.getAbsolutePath());
            } catch (IOException e) {
                System.out.println("Error saving logs: " + e.getMessage());
            }
        }
    }
}
