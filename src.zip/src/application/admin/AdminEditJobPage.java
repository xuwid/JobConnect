package application.admin;

import application.SceneManager;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class AdminEditJobPage {
    private final SceneManager sceneManager;
    private final BorderPane root;
    private final String[] job; // Job data to edit

    public AdminEditJobPage(SceneManager sceneManager, BorderPane root, String[] job) {
        this.sceneManager = sceneManager;
        this.root = root;
        this.job = job;
    }

    /**
     * Returns the interface for editing a job.
     */
    public VBox getView() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);

        // Title
        Label title = new Label("Admin Edit Job Details");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        title.setTextFill(Color.DARKBLUE);

        // Form Fields
        TextField idField = new TextField(job[0]);
        idField.setEditable(false);
        idField.setPromptText("Job ID");

        TextField titleField = new TextField(job[1]);
        titleField.setPromptText("Job Title");

        TextArea descriptionField = new TextArea(job[2]);
        descriptionField.setPromptText("Job Description");
        descriptionField.setPrefRowCount(5);

        TextField salaryField = new TextField(job[3]);
        salaryField.setPromptText("Salary");

        // Save Button
        Button saveButton = new Button("Save Changes");
        saveButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        saveButton.setOnAction(e -> {
            job[1] = titleField.getText();
            job[2] = descriptionField.getText();
            job[3] = salaryField.getText();

            // Validate and save changes
            if (!job[1].isEmpty() && !job[2].isEmpty() && !job[3].isEmpty()) {
                System.out.println("Job updated: " + job[1]);
                returnToManageJobsPage();
            } else {
                System.out.println("All fields must be filled!");
            }
        });

        // Cancel Button
        Button cancelButton = new Button("Cancel");
        cancelButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        cancelButton.setOnAction(e -> returnToManageJobsPage());

        HBox buttonContainer = new HBox(10, saveButton, cancelButton);
        buttonContainer.setAlignment(Pos.CENTER);

        layout.getChildren().addAll(title, idField, titleField, descriptionField, salaryField, buttonContainer);
        return layout;
    }

    /**
     * Returns to the Manage Jobs page.
     */
    private void returnToManageJobsPage() {
        ManageJobsPage manageJobsPage = new ManageJobsPage(sceneManager, root);
        root.setCenter(manageJobsPage.getView());
    }
}
