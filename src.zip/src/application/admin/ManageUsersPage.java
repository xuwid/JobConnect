package application.admin;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import application.SceneManager;

public class ManageUsersPage {
    private final SceneManager sceneManager;
    private final BorderPane root;
    private VBox userListContainer; // Container for dynamic user rows
    private List<String[]> users;   // Full list of users

    public ManageUsersPage(SceneManager sceneManager, BorderPane root) {
        this.sceneManager = sceneManager;
        this.root = root;

        // Initialize users (simulated data)
        this.users = new ArrayList<>();
        users.add(new String[]{"1", "John Doe", "john.doe@example.com"});
        users.add(new String[]{"2", "Jane Smith", "jane.smith@example.com"});
        users.add(new String[]{"3", "Alice Johnson", "alice.johnson@example.com"});
    }

    /**
     * Returns the complete scene for managing users.
     */
    public Scene getScene() {
        // Set up the center view (main content)
        VBox content = getView();
        root.setCenter(content);

        // Return the root wrapped in a scene
        return new Scene(root, 1000, 600);
    }

    /**
     * Returns the interface for managing users.
     */
    public VBox getView() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);

        Label titleLabel = new Label("Manage Users");
        titleLabel.setFont(Font.font("Arial", 24));
        titleLabel.setTextFill(Color.DARKBLUE);

        // Search bar
        HBox searchBar = createSearchBar();

        // Scrollable pane for users
        ScrollPane scrollPane = createScrollableUserList();

        layout.getChildren().addAll(titleLabel, searchBar, scrollPane);
        return layout;
    }

    /**
     * Creates a search bar to filter users.
     */
    private HBox createSearchBar() {
        HBox searchBar = new HBox(10);
        searchBar.setAlignment(Pos.CENTER);
        searchBar.setPadding(new Insets(10));
        searchBar.setStyle("-fx-background-color: #ffffff; -fx-background-radius: 10;");

        TextField searchField = new TextField();
        searchField.setPromptText("Search by ID, Name, or Email");
        searchField.setPrefWidth(300);

        Button searchButton = new Button("Search");
        searchButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");
        searchButton.setOnAction(e -> performSearch(searchField.getText()));

        searchBar.getChildren().addAll(searchField, searchButton);
        return searchBar;
    }

    /**
     * Creates a scrollable pane for displaying users.
     */
    private ScrollPane createScrollableUserList() {
        userListContainer = new VBox(10);
        userListContainer.setAlignment(Pos.TOP_CENTER);
        userListContainer.setPadding(new Insets(10));

        // Populate with all users initially
        updateUserList(users);

        ScrollPane scrollPane = new ScrollPane(userListContainer);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent;");

        return scrollPane;
    }

    /**
     * Performs a search and updates the user list dynamically.
     */
    private void performSearch(String query) {
        if (query == null || query.trim().isEmpty()) {
            updateUserList(users); // Show all users if search is empty
            return;
        }

        // Filter users based on the query
        List<String[]> filteredUsers = users.stream()
                .filter(user -> user[0].equalsIgnoreCase(query) || 
                                user[1].toLowerCase().contains(query.toLowerCase()) || 
                                user[2].toLowerCase().contains(query.toLowerCase()))
                .collect(Collectors.toList());

        updateUserList(filteredUsers);
    }

    /**
     * Updates the user list in the scrollable pane.
     */
    private void updateUserList(List<String[]> userList) {
        userListContainer.getChildren().clear();

        if (userList.isEmpty()) {
            Label noResultsLabel = new Label("No users found.");
            noResultsLabel.setTextFill(Color.RED);
            userListContainer.getChildren().add(noResultsLabel);
        } else {
            for (String[] user : userList) {
                HBox userRow = createUserRow(user);
                userListContainer.getChildren().add(userRow);
            }
        }
    }

    /**
     * Creates a row for a single user with edit and delete options.
     */
    private HBox createUserRow(String[] user) {
        HBox row = new HBox(20);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setStyle("-fx-background-color: #ecf0f1; -fx-border-color: #dcdcdc; -fx-padding: 10;");
        row.setPadding(new Insets(10));

        Label idLabel = new Label("ID: " + user[0]);
        idLabel.setFont(Font.font("Arial", 14));
        Label nameLabel = new Label("Name: " + user[1]);
        nameLabel.setFont(Font.font("Arial", 14));
        Label emailLabel = new Label("Email: " + user[2]);
        emailLabel.setFont(Font.font("Arial", 14));

        Button editButton = new Button("Edit");
        editButton.setStyle("-fx-background-color: #f1c40f; -fx-text-fill: white;");
        editButton.setOnAction(e -> loadEditUserPage(user));

        Button deleteButton = new Button("Delete");
        deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        deleteButton.setOnAction(e -> {
            System.out.println("User deleted: " + user[1]);
            users = users.stream().filter(u -> !u[0].equals(user[0])).collect(Collectors.toList());
            updateUserList(users);
        });

        row.getChildren().addAll(idLabel, nameLabel, emailLabel, editButton, deleteButton);
        return row;
    }

    /**
     * Navigates to the Edit User Page for the selected user.
     */
    private void loadEditUserPage(String[] user) {
        EditUserPage editUserPage = new EditUserPage(sceneManager, root, user);
        root.setCenter(editUserPage.getView());
    }
}
