package application.admin;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import application.SceneManager;

public class ManageJobsPage {
    private final SceneManager sceneManager;
    private final BorderPane root;
    private VBox jobListContainer; // Container for dynamic job cards
    private List<String[]> jobs;   // Simulated job data

    public ManageJobsPage(SceneManager sceneManager, BorderPane root) {
        this.sceneManager = sceneManager;
        this.root = root;

        // Initialize jobs (simulated data)
        this.jobs = new ArrayList<>();
        jobs.add(new String[]{"1", "John Doe (101)", "Software Engineer", "Develop applications", "$100,000"});
        jobs.add(new String[]{"2", "Jane Smith (102)", "Project Manager", "Manage projects", "$80,000"});
        jobs.add(new String[]{"3", "Alice Johnson (103)", "Data Scientist", "Analyze data", "$120,000"});
    }

    /**
     * Returns the interface for managing jobs.
     */
    public VBox getView() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);

        Label titleLabel = new Label("Manage Jobs");
        titleLabel.setFont(Font.font("Arial", 24));
        titleLabel.setTextFill(Color.DARKBLUE);

        // Search bar
        HBox searchBar = createSearchBar();

        // Scrollable pane for jobs
        ScrollPane scrollPane = createScrollableJobList();

        layout.getChildren().addAll(titleLabel, searchBar, scrollPane);
        return layout;
    }

    /**
     * Creates a search bar to filter jobs.
     */
    private HBox createSearchBar() {
        HBox searchBar = new HBox(10);
        searchBar.setAlignment(Pos.CENTER);
        searchBar.setPadding(new Insets(10));
        searchBar.setStyle("-fx-background-color: #ffffff; -fx-background-radius: 10;");

        TextField searchField = new TextField();
        searchField.setPromptText("Search by Job ID, Poster ID, Poster Name, Description, or Salary");
        searchField.setPrefWidth(400);

        Button searchButton = new Button("Search");
        searchButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");
        searchButton.setOnAction(e -> performSearch(searchField.getText()));

        searchBar.getChildren().addAll(searchField, searchButton);
        return searchBar;
    }

    /**
     * Creates a scrollable pane for displaying jobs.
     */
    private ScrollPane createScrollableJobList() {
        jobListContainer = new VBox(10);
        jobListContainer.setAlignment(Pos.TOP_CENTER);
        jobListContainer.setPadding(new Insets(10));

        // Populate with all jobs initially
        updateJobList(jobs);

        ScrollPane scrollPane = new ScrollPane(jobListContainer);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent;");

        return scrollPane;
    }

    /**
     * Performs a search and updates the job list dynamically.
     */
    private void performSearch(String query) {
        if (query == null || query.trim().isEmpty()) {
            updateJobList(jobs); // Show all jobs if search is empty
            return;
        }

        // Filter jobs based on the query
        List<String[]> filteredJobs = jobs.stream()
                .filter(job -> job[0].equalsIgnoreCase(query) || 
                               job[1].toLowerCase().contains(query.toLowerCase()) || 
                               job[2].toLowerCase().contains(query.toLowerCase()) || 
                               job[3].toLowerCase().contains(query.toLowerCase()) || 
                               job[4].toLowerCase().contains(query.toLowerCase()))
                .collect(Collectors.toList());

        updateJobList(filteredJobs);
    }

    /**
     * Updates the job list in the scrollable pane.
     */
    private void updateJobList(List<String[]> jobList) {
        jobListContainer.getChildren().clear();

        if (jobList.isEmpty()) {
            Label noResultsLabel = new Label("No jobs found.");
            noResultsLabel.setTextFill(Color.RED);
            jobListContainer.getChildren().add(noResultsLabel);
        } else {
            for (String[] job : jobList) {
                VBox jobCard = createJobCard(job);
                jobListContainer.getChildren().add(jobCard);
            }
        }
    }

    /**
     * Creates a card for a single job with options to edit, delete, or view details.
     */
    private VBox createJobCard(String[] job) {
        VBox card = new VBox(10);
        card.setPadding(new Insets(15));
        card.setStyle("-fx-background-color: #ecf0f1; -fx-border-color: #bdc3c7; -fx-border-radius: 10; -fx-background-radius: 10;");
        card.setAlignment(Pos.CENTER_LEFT);

        Label idLabel = new Label("Job ID: " + job[0]);
        idLabel.setFont(Font.font("Arial", 14));
        Label posterLabel = new Label("Job Poster: " + job[1]);
        posterLabel.setFont(Font.font("Arial", 14));
        Label titleLabel = new Label("Title: " + job[2]);
        titleLabel.setFont(Font.font("Arial", 16));
        titleLabel.setStyle("-fx-font-weight: bold;");
        Label descriptionLabel = new Label("Description: " + job[3]);
        descriptionLabel.setFont(Font.font("Arial", 14));
        Label salaryLabel = new Label("Salary: " + job[4]);
        salaryLabel.setFont(Font.font("Arial", 14));

        Button editButton = new Button("Edit");
        editButton.setStyle("-fx-background-color: #f1c40f; -fx-text-fill: white;");
        editButton.setOnAction(e -> loadEditJobPage(job));

        Button deleteButton = new Button("Delete");
        deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        deleteButton.setOnAction(e -> {
            System.out.println("Job deleted: " + job[2]);
            jobs = jobs.stream().filter(j -> !j[0].equals(job[0])).collect(Collectors.toList());
            updateJobList(jobs);
        });

        Button detailsButton = new Button("View Details");
        detailsButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white;");
        detailsButton.setOnAction(e -> viewJobDetails(job));

        HBox buttonContainer = new HBox(10, detailsButton, editButton, deleteButton);
        buttonContainer.setAlignment(Pos.CENTER);

        card.getChildren().addAll(idLabel, posterLabel, titleLabel, descriptionLabel, salaryLabel, buttonContainer);
        return card;
    }

    /**
     * Navigates to the Edit Job Page for the selected job.
     */
    private void loadEditJobPage(String[] job) {
        AdminEditJobPage editJobPage = new AdminEditJobPage(sceneManager, root, job);
        root.setCenter(editJobPage.getView());
    }

    /**
     * Shows the job details in a new view.
     */
    private void viewJobDetails(String[] job) {
        VBox detailsView = new VBox(20);
        detailsView.setPadding(new Insets(20));
        detailsView.setAlignment(Pos.TOP_CENTER);

        Label title = new Label("Job Details");
        title.setFont(Font.font("Arial", 24));
        title.setTextFill(Color.DARKBLUE);

        Label idLabel = new Label("Job ID: " + job[0]);
        Label posterLabel = new Label("Job Poster: " + job[1]);
        Label titleLabel = new Label("Title: " + job[2]);
        Label descriptionLabel = new Label("Description: " + job[3]);
        Label salaryLabel = new Label("Salary: " + job[4]);

        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        backButton.setOnAction(e -> root.setCenter(getView()));

        detailsView.getChildren().addAll(title, idLabel, posterLabel, titleLabel, descriptionLabel, salaryLabel, backButton);
        root.setCenter(detailsView);
    }
}
