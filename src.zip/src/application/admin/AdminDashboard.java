/*
 * package application;
 * 
 * import javafx.geometry.Insets; import javafx.geometry.Pos; import
 * javafx.scene.Node; import javafx.scene.control.Button; import
 * javafx.scene.control.Label; import javafx.scene.layout.*; import
 * javafx.scene.paint.Color; import javafx.scene.text.Font; import
 * javafx.scene.text.FontWeight;
 * 
 * public class AdminDashboard { private final SceneManager sceneManager;
 * private final BorderPane root;
 * 
 * public AdminDashboard(SceneManager sceneManager, BorderPane root) {
 * this.sceneManager = sceneManager; this.root = root; }
 * 
 *//**
	 * Returns the admin dashboard interface.
	 */
/*
 * public VBox getView() { VBox layout = new VBox(20);
 * layout.setAlignment(Pos.TOP_CENTER); layout.setPadding(new Insets(20));
 * 
 * // Title Label titleLabel = new Label("Admin Dashboard");
 * titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
 * titleLabel.setTextFill(Color.DARKBLUE);
 * 
 * // Admin Functionality Buttons Button manageUsersButton =
 * createNavButton("Manage Users", new ManageUsersPage(sceneManager,
 * root)::getView); Button manageJobsButton = createNavButton("Manage Jobs", new
 * ManageJobsPage(sceneManager, root)::getView); Button viewLogsButton =
 * createNavButton("View Logs", new SystemLogsPage(sceneManager,
 * root)::getView);
 * 
 * // Add buttons to layout layout.getChildren().addAll(titleLabel,
 * manageUsersButton, manageJobsButton, viewLogsButton); return layout; }
 * 
 *//**
	 * Creates a navigation button for admin functionalities.
	 *//*
		 * private Button createNavButton(String text, Runnable action) { Button button
		 * = new Button(text); button.setPrefWidth(200); button.
		 * setStyle("-fx-background-color: #2c3e50; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10;"
		 * ); button.setOnAction(e -> { // Execute the action and load the new view into
		 * the center of the root Node view = (Node) action.run(); root.setCenter(view);
		 * }); return button; } }
		 */
