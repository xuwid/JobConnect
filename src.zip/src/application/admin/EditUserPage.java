package application.admin;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import java.util.ArrayList;
import java.util.List;

import application.SceneManager;


public class EditUserPage {
    private final SceneManager sceneManager;
    private final BorderPane root;
    private final String[] user;

    public EditUserPage(SceneManager sceneManager, BorderPane root, String[] user) {
        this.sceneManager = sceneManager;
        this.root = root;
        this.user = user;
    }

    /**
     * Returns the interface for editing user details.
     */
    public VBox getView() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);

        // Title
        Text title = new Text("Edit User Details");
        title.setFont(Font.font("Arial", 24));
        title.setFill(Color.DARKBLUE);

        // Form Fields
        TextField idField = new TextField(user[0]);
        idField.setEditable(false);

        TextField nameField = new TextField(user[1]);
        TextField emailField = new TextField(user[2]);

        // Save and Back Buttons
        Button saveButton = new Button("Save Changes");
        saveButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        saveButton.setOnAction(e -> {
            user[1] = nameField.getText();
            user[2] = emailField.getText();
            System.out.println("User updated: " + user[1]);
            root.setCenter(new ManageUsersPage(sceneManager, root).getView());
        });

        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        backButton.setOnAction(e -> root.setCenter(new ManageUsersPage(sceneManager, root).getView()));

        layout.getChildren().addAll(title, idField, nameField, emailField, saveButton, backButton);
        return layout;
    }
}
