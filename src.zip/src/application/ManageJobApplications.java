package application;

import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.List;

public class ManageJobApplications {

    private final BorderPane dashboardRoot;
    private final String jobTitle;
    private final String jobDescription;
    private final String jobId;
    private final List<Applicant> applicants; // List to track applicants
    private final VBox applicantsLayout; // VBox to dynamically update the applicants' display
    private HBox selectedApplicantBox; // Track the currently selected applicant's HBox

    public ManageJobApplications(BorderPane dashboardRoot, String jobTitle, String jobDescription, String jobId) {
        this.dashboardRoot = dashboardRoot;
        this.jobTitle = jobTitle;
        this.jobDescription = jobDescription;
        this.jobId = jobId;
        this.applicants = initializeApplicants(); // Initialize applicants list
        this.applicantsLayout = new VBox(15); // VBox to hold applicant views
        this.selectedApplicantBox = null; // Initially, no applicant is selected
    }

    public VBox getView() {
        VBox layout = new VBox(25);
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setPadding(new Insets(20));
        layout.setStyle("-fx-background-color: #f9fafc;");

        // Job Information
        Label jobInfoLabel = new Label("Job Title: " + jobTitle);
        jobInfoLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #34495e;");

        // Section title for applicants
        Label applicantsTitleLabel = new Label("Applicants");
        applicantsTitleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #34495e;");

        // Populate initial list of applicants
        refreshApplicantList();

        // Wrap the applicants list inside a ScrollPane to make it scrollable
        ScrollPane scrollPane = new ScrollPane(applicantsLayout);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: transparent; -fx-focus-color: transparent;");

        // Back to Dashboard button
//        Button backButton = new Button("Back to Dashboard");
//        backButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 8;");
//        backButton.setOnMouseEntered(e -> backButton.setStyle("-fx-background-color: #1f618d; -fx-text-fill: white;"));
//        backButton.setOnMouseExited(e -> backButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;"));
//        backButton.setOnAction(e -> dashboardRoot.setCenter(new Label("Returning to Dashboard...")));

        // Add elements to the layout
        layout.getChildren().addAll(jobInfoLabel, applicantsTitleLabel, scrollPane);

        return layout;
    }

    private List<Applicant> initializeApplicants() {
        List<Applicant> applicants = new ArrayList<>();
        applicants.add(new Applicant("John Doe", "john.doe@email.com", "Software Developer", "Pending",
                List.of("Junior Developer at TechCorp", "Intern at CodeBase Inc.")));
        applicants.add(new Applicant("Jane Smith", "jane.smith@email.com", "UX Designer", "Pending",
                List.of("UI Designer at DesignX", "Graphic Designer at CreativeWorks")));
        applicants.add(new Applicant("Robert Brown", "robert.brown@email.com", "Data Analyst", "Pending",
                List.of("Data Scientist at AnalyzeAI", "Intern at BigData Solutions")));
        return applicants;
    }

    private void refreshApplicantList() {
        applicantsLayout.getChildren().clear(); // Clear the current list
        for (Applicant applicant : applicants) {
            HBox applicantBox = createApplicantView(applicant);

            // Get the buttons from the applicant box
            HBox buttonsBox = (HBox) ((VBox) applicantBox.getChildren().get(0)).getChildren().get(1);
            Button acceptBtn = (Button) buttonsBox.getChildren().get(1);
            Button declineBtn = (Button) buttonsBox.getChildren().get(2);

            // Disable buttons if the applicant is already accepted
            if ("Accepted".equalsIgnoreCase(applicant.getStatus())) {
                acceptBtn.setDisable(true);
                declineBtn.setDisable(true);
            }

            applicantsLayout.getChildren().add(applicantBox);
        }
    }

    private HBox createApplicantView(Applicant applicant) {
        HBox applicantBox = new HBox(15);
        applicantBox.setPadding(new Insets(15));
        applicantBox.setStyle("-fx-background-color: #ffffff; -fx-border-color: #dce1e3; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 5, 0.5, 0, 0);");

        // Details Section
        VBox detailsBox = new VBox(8); // Compact stacking of labels
        detailsBox.setAlignment(Pos.TOP_LEFT);

        Label nameLabel = new Label("Name: " + applicant.getName());
        nameLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #34495e;");

        Label emailLabel = new Label("Email: " + applicant.getEmail());
        emailLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #7f8c8d;");

        Label jobLabel = new Label("Applied for: " + applicant.getJobAppliedFor());
        jobLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #7f8c8d;");

        Label statusLabel = new Label("Status: " + applicant.getStatus());
        statusLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: " + getStatusColor(applicant.getStatus()) + ";");

        detailsBox.getChildren().addAll(nameLabel, emailLabel, jobLabel, statusLabel);

        // Buttons Section
        HBox buttonsBox = new HBox(10);
        buttonsBox.setAlignment(Pos.CENTER_RIGHT);

        Button viewProfileBtn = createActionButton("View Profile", "#2980b9");
        viewProfileBtn.setOnAction(e -> viewProfile(applicant));

        Button acceptBtn = createActionButton("Accept", "#27ae60");
        Button declineBtn = createActionButton("Decline", "#e74c3c");

        setupApplicationActionButtons(acceptBtn, declineBtn, applicant, applicantBox);

        buttonsBox.getChildren().addAll(viewProfileBtn, acceptBtn, declineBtn);

        // Combine details and buttons into main card
        VBox contentBox = new VBox(10);
        contentBox.getChildren().addAll(detailsBox, buttonsBox);

        applicantBox.getChildren().add(contentBox);
        return applicantBox;
    }

    private void setupApplicationActionButtons(Button acceptBtn, Button declineBtn, Applicant applicant, HBox applicantBox) {
        acceptBtn.setOnAction(e -> {
            applicant.setStatus("Accepted");

            // Disable the Decline button
            declineBtn.setDisable(true);
            acceptBtn.setDisable(true); // Optionally disable the Accept button as well
            System.out.println(applicant.getName() + " has been accepted.");
            refreshApplicantList(); // Refresh to update the status
        });

        declineBtn.setOnAction(e -> {
            applicants.remove(applicant); // Remove applicant from the list
            applicantsLayout.getChildren().remove(applicantBox); // Remove the card from the UI
            System.out.println(applicant.getName() + " has been declined.");
        });
    }

    private Button createActionButton(String text, String color) {
        Button button = new Button(text);

        // Base style
        String baseStyle = "-fx-background-color: " + color + "; -fx-text-fill: white; -fx-font-size: 12px; -fx-padding: 6 12; -fx-border-radius: 5; -fx-background-radius: 5;";
        String hoverStyle = "-fx-background-color: #1f618d; -fx-text-fill: white; -fx-font-size: 12px; -fx-padding: 6 12; -fx-border-radius: 5; -fx-background-radius: 5;";

        // Apply base style
        button.setStyle(baseStyle);

        // Hover behavior
        button.setOnMouseEntered(e -> button.setStyle(hoverStyle));
        button.setOnMouseExited(e -> button.setStyle(baseStyle));

        return button;
    }

    private void viewProfile(Applicant applicant) {
        dashboardRoot.setCenter(getProfileView(applicant));
    }

    private VBox getProfileView(Applicant applicant) {
        VBox profileLayout = new VBox(20);
        profileLayout.setAlignment(Pos.TOP_CENTER);
        profileLayout.setPadding(new Insets(20));
        profileLayout.setStyle("-fx-background-color: #f9fafc;");

        // Title
        Label titleLabel = new Label("Applicant Profile");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #34495e;");

        // Applicant Details
        Label nameLabel = new Label("Name: " + applicant.getName());
        nameLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: #34495e;");

        Label emailLabel = new Label("Email: " + applicant.getEmail());
        emailLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #7f8c8d;");

        Label jobLabel = new Label("Applied for: " + applicant.getJobAppliedFor());
        jobLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #7f8c8d;");

        Label statusLabel = new Label("Status: " + applicant.getStatus());
        statusLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: " + getStatusColor(applicant.getStatus()) + ";");

        // Previous Jobs Section
        Label previousJobsTitle = new Label("Previous Jobs:");
        previousJobsTitle.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #34495e;");

        VBox previousJobsList = new VBox(10);
        previousJobsList.setPadding(new Insets(10));
        previousJobsList.setStyle("-fx-background-color: #ffffff; -fx-border-radius: 8; -fx-padding: 15;");

        if (applicant.getPreviousJobs() != null && !applicant.getPreviousJobs().isEmpty()) {
            for (String job : applicant.getPreviousJobs()) {
                Label jobLabelItem = new Label("- " + job);
                jobLabelItem.setStyle("-fx-font-size: 14px; -fx-text-fill: #7f8c8d;");
                previousJobsList.getChildren().add(jobLabelItem);
            }
        } else {
            Label noJobsLabel = new Label("No previous jobs listed.");
            noJobsLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #e74c3c;");
            previousJobsList.getChildren().add(noJobsLabel);
        }

        // Back Button
        Button backButton = new Button("Back to Applicants");
        backButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-border-radius: 8;");
        backButton.setOnMouseEntered(e -> backButton.setStyle("-fx-background-color: #1f618d; -fx-text-fill: white;"));
        backButton.setOnMouseExited(e -> backButton.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;"));
        backButton.setOnAction(e -> dashboardRoot.setCenter(getView()));

        // Add all elements to the layout
        profileLayout.getChildren().addAll(titleLabel, nameLabel, emailLabel, jobLabel, statusLabel, previousJobsTitle, previousJobsList, backButton);

        return profileLayout;
    }

    private String getStatusColor(String status) {
        switch (status.toLowerCase()) {
            case "accepted":
                return "#27ae60"; // Green for accepted
            case "declined":
                return "#e74c3c"; // Red for declined
            default:
                return "#e67e22"; // Orange for pending
        }
    }

    public static class Applicant {
        private final String name;
        private final String email;
        private final String jobAppliedFor;
        private String status;
        private final List<String> previousJobs; // New field for previous jobs

        public Applicant(String name, String email, String jobAppliedFor, String status, List<String> previousJobs) {
            this.name = name;
            this.email = email;
            this.jobAppliedFor = jobAppliedFor;
            this.status = status;
            this.previousJobs = previousJobs;
        }

        public String getName() {
            return name;
        }

        public String getEmail() {
            return email;
        }

        public String getJobAppliedFor() {
            return jobAppliedFor;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public List<String> getPreviousJobs() {
            return previousJobs;
        }
    }
}
