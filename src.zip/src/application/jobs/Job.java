package application.jobs;

import java.util.List;

public class Job {
    private String title;
    private String description;
    private String salary;
    private String location;
    private List<String> requirements;

    public Job(String title, String description, String salary, String location, List<String> requirements) {
        this.title = title;
        this.description = description;
        this.salary = salary;
        this.location = location;
        this.requirements = requirements;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getSalary() {
        return salary;
    }

    public String getLocation() {
        return location;
    }

    public List<String> getRequirements() {
        return requirements;
    }

    // Setters
    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setRequirements(List<String> requirements) {
        this.requirements = requirements;
    }

    @Override
    public String toString() {
        return title + " - $" + salary + " - " + location;
    }
}
