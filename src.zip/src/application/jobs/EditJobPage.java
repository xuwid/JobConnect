package application.jobs;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import java.util.ArrayList;
import java.util.List;

import application.JobManagementPage;
import application.SceneManager;

public class EditJobPage {
    private final SceneManager sceneManager;
    private final BorderPane dashboardRoot;
    private Job selectedJob; // Track the selected job for editing

    private TextField editJobTitleField;
    private TextArea editJobDescriptionField;
    private TextField editSalaryField;
    private TextField editLocationField;
    private ComboBox<String> requirementsDropdown;
    private Label selectedRequirementsLabel;
    private List<String> selectedRequirements;

    public EditJobPage(SceneManager sceneManager, BorderPane dashboardRoot) {
        this.sceneManager = sceneManager;
        this.dashboardRoot = dashboardRoot;
    }

    public ScrollPane getView() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setStyle("-fx-background-color: #f9fafc;");

        Label titleLabel = new Label("Edit Jobs");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #34495e;");

        // List of jobs
        List<Job> jobs = new ArrayList<>();
        jobs.add(new Job("Software Engineer", "Develop applications", "100000", "Remote", List.of("Technical Test")));
        jobs.add(new Job("Project Manager", "Manage projects", "80000", "Onsite", List.of("Communication Test")));
        jobs.add(new Job("Data Scientist", "Analyze data", "120000", "Hybrid", List.of("Aptitude Test")));
        jobs.add(new Job("UX Designer", "Design user interfaces", "90000", "Remote", List.of("Coding Challenge")));
        jobs.add(new Job("Frontend Developer", "Build front-end applications", "95000", "Hybrid", List.of("Design Test")));

        // Job Cards Horizontal Scroll Pane
        ScrollPane jobScrollPane = createJobCardsScrollPane(jobs);

        // Edit Fields
        VBox editFieldsContainer = new VBox(15);
        editFieldsContainer.setPadding(new Insets(20));
        editFieldsContainer.setAlignment(Pos.TOP_CENTER);
        editFieldsContainer.setStyle("-fx-background-color: #ffffff; -fx-border-color: #dce1e3; -fx-border-radius: 10; -fx-background-radius: 10;");

        editJobTitleField = new TextField();
        editJobTitleField.setPromptText("Edit Job Title");
        editJobTitleField.setStyle("-fx-padding: 10; -fx-font-size: 14px; -fx-border-color: #dce1e3; -fx-border-radius: 5;");

        editJobDescriptionField = new TextArea();
        editJobDescriptionField.setPromptText("Edit Job Description");
        editJobDescriptionField.setPrefRowCount(5);
        editJobDescriptionField.setStyle("-fx-padding: 10; -fx-font-size: 14px; -fx-border-color: #dce1e3; -fx-border-radius: 5;");

        editSalaryField = new TextField();
        editSalaryField.setPromptText("Edit Salary");
        editSalaryField.setStyle("-fx-padding: 10; -fx-font-size: 14px; -fx-border-color: #dce1e3; -fx-border-radius: 5;");

        editLocationField = new TextField();
        editLocationField.setPromptText("Edit Location");
        editLocationField.setStyle("-fx-padding: 10; -fx-font-size: 14px; -fx-border-color: #dce1e3; -fx-border-radius: 5;");

        requirementsDropdown = new ComboBox<>();
        requirementsDropdown.getItems().addAll(
                "Technical Test", "Aptitude Test", "Coding Challenge", "Communication Test"
        );
        requirementsDropdown.setPromptText("Add Requirement");

        selectedRequirements = new ArrayList<>();
        selectedRequirementsLabel = new Label("Requirements: None");
        selectedRequirementsLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #7f8c8d;");

        Button addRequirementButton = new Button("Add Requirement");
        addRequirementButton.setOnAction(e -> {
            String selectedRequirement = requirementsDropdown.getValue();
            if (selectedRequirement != null && !selectedRequirements.contains(selectedRequirement)) {
                selectedRequirements.add(selectedRequirement);
                selectedRequirementsLabel.setText("Requirements: " + String.join(", ", selectedRequirements));
            }
        });

        Button saveChangesButton = new Button("Save Changes");
        saveChangesButton.setStyle("-fx-background-color: #2c3e50; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10;");
        saveChangesButton.setOnAction(e -> saveJobChanges());

        Button backButton = new Button("Back to Manage Options");
        backButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10;");
        backButton.setOnAction(e -> {
            JobManagementPage jobManagementPage = new JobManagementPage(sceneManager, dashboardRoot);
            dashboardRoot.setCenter(jobManagementPage.getView());
        });

        editFieldsContainer.getChildren().addAll(
                editJobTitleField, editJobDescriptionField, editSalaryField,
                editLocationField, requirementsDropdown, addRequirementButton, selectedRequirementsLabel,
                saveChangesButton
        );

        layout.getChildren().addAll(titleLabel, jobScrollPane, editFieldsContainer, backButton);

        ScrollPane scrollPane = new ScrollPane(layout);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent; -fx-focus-color: transparent;");
        return scrollPane;
    }

    private ScrollPane createJobCardsScrollPane(List<Job> jobs) {
        HBox jobCardsContainer = new HBox(20);
        jobCardsContainer.setPadding(new Insets(10));
        jobCardsContainer.setAlignment(Pos.CENTER_LEFT);
        jobCardsContainer.setStyle("-fx-background-color: #ecf0f1; -fx-padding: 20; -fx-border-color: #dce1e3; -fx-border-radius: 10; -fx-background-radius: 10;");

        for (Job job : jobs) {
            VBox jobCard = createJobCard(job);
            jobCardsContainer.getChildren().add(jobCard);
        }

        ScrollPane jobScrollPane = new ScrollPane(jobCardsContainer);
        jobScrollPane.setFitToHeight(true);
        jobScrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
        jobScrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        jobScrollPane.setStyle("-fx-background: transparent; -fx-border-radius: 10; -fx-background-radius: 10;");

        return jobScrollPane;
    }

    private VBox createJobCard(Job job) {
        VBox jobCard = new VBox(10);
        jobCard.setPadding(new Insets(10));
        jobCard.setPrefWidth(200);
        jobCard.setStyle("-fx-background-color: white; -fx-border-radius: 10; -fx-border-color: #bdc3c7; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 5, 0.5, 0, 0);");

        Label titleLabel = new Label(job.getTitle());
        titleLabel.setFont(Font.font("Arial", 16));
        titleLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #34495e;");
        job.setTitleLabel(titleLabel);

        Label salaryLabel = new Label("$" + job.getSalary());
        salaryLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #2ecc71;");
        job.setSalaryLabel(salaryLabel);

        Label locationLabel = new Label(job.getLocation());
        locationLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #3498db;");
        job.setLocationLabel(locationLabel);

        jobCard.getChildren().addAll(titleLabel, salaryLabel, locationLabel);
        jobCard.setOnMouseClicked(e -> populateFieldsWithJob(job));

        job.setCard(jobCard);
        return jobCard;
    }

    private void populateFieldsWithJob(Job job) {
        selectedJob = job;

        editJobTitleField.setText(job.getTitle());
        editJobDescriptionField.setText(job.getDescription());
        editSalaryField.setText(job.getSalary());
        editLocationField.setText(job.getLocation());

        selectedRequirements = new ArrayList<>(job.getRequirements());
        selectedRequirementsLabel.setText("Requirements: " + String.join(", ", selectedRequirements));
    }

    private void saveJobChanges() {
        if (selectedJob != null) {
            String newTitle = editJobTitleField.getText();
            String newDescription = editJobDescriptionField.getText();
            String newSalary = editSalaryField.getText();
            String newLocation = editLocationField.getText();

            if (!newTitle.isEmpty() && !newDescription.isEmpty() && !newSalary.isEmpty() && !newLocation.isEmpty()) {
                selectedJob.setTitle(newTitle);
                selectedJob.setDescription(newDescription);
                selectedJob.setSalary(newSalary);
                selectedJob.setLocation(newLocation);
                selectedJob.setRequirements(new ArrayList<>(selectedRequirements));

                updateJobCard(selectedJob);
            } else {
                System.out.println("Please fill in all fields.");
            }
        } else {
            System.out.println("Please select a job to edit.");
        }
    }

    private void updateJobCard(Job job) {
        if (job.getCard() != null) {
            job.getTitleLabel().setText(job.getTitle());
            job.getSalaryLabel().setText("$" + job.getSalary());
            job.getLocationLabel().setText(job.getLocation());
        }
    }

    public static class Job {
        private String title;
        private String description;
        private String salary;
        private String location;
        private List<String> requirements;

        private Label titleLabel;
        private Label salaryLabel;
        private Label locationLabel;
        private VBox card;

        public Job(String title, String description, String salary, String location, List<String> requirements) {
            this.title = title;
            this.description = description;
            this.salary = salary;
            this.location = location;
            this.requirements = requirements;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getSalary() {
            return salary;
        }

        public void setSalary(String salary) {
            this.salary = salary;
        }

        public String getLocation() {
            return location;
        }

        public void setLocation(String location) {
            this.location = location;
        }

        public List<String> getRequirements() {
            return requirements;
        }

        public void setRequirements(List<String> requirements) {
            this.requirements = requirements;
        }

        public Label getTitleLabel() {
            return titleLabel;
        }

        public void setTitleLabel(Label titleLabel) {
            this.titleLabel = titleLabel;
        }

        public Label getSalaryLabel() {
            return salaryLabel;
        }

        public void setSalaryLabel(Label salaryLabel) {
            this.salaryLabel = salaryLabel;
        }

        public Label getLocationLabel() {
            return locationLabel;
        }

        public void setLocationLabel(Label locationLabel) {
            this.locationLabel = locationLabel;
        }

        public VBox getCard() {
            return card;
        }

        public void setCard(VBox card) {
            this.card = card;
        }
    }
}
