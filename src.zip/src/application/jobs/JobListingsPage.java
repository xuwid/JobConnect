package application.jobs;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.BorderPane;

import java.util.ArrayList;
import java.util.List;

import application.SceneManager;

public class JobListingsPage {
    private final SceneManager sceneManager;
    private final BorderPane dashboardRoot; // To dynamically update the center area

    public JobListingsPage(SceneManager sceneManager, BorderPane dashboardRoot) {
        this.sceneManager = sceneManager;
        this.dashboardRoot = dashboardRoot;
    }

    /**
     * Generates the main view for the Job Listings page.
     */
    public VBox getView() {
        VBox layout = new VBox(20);
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setPadding(new Insets(20));
        layout.setStyle("-fx-background-color: #f4f6f7;");

        Label titleLabel = new Label("Available Jobs");
        titleLabel.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #34495e;");

        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);
        scrollPane.setPadding(new Insets(10));
        scrollPane.setStyle("-fx-background-color: transparent; -fx-focus-color: transparent;");

        VBox jobContainer = new VBox(15);
        jobContainer.setPadding(new Insets(10));

        List<Job> jobs = generateJobs();
        for (Job job : jobs) {
            jobContainer.getChildren().add(createJobBox(job));
        }

        scrollPane.setContent(jobContainer);

        layout.getChildren().addAll(titleLabel, scrollPane);
        return layout;
    }

    /**
     * Creates a styled job card for each job listing.
     */
    private VBox createJobBox(Job job) {
        VBox jobBox = new VBox(10);
        jobBox.setPadding(new Insets(15));
        jobBox.setStyle("-fx-border-color: #dce1e3; -fx-border-width: 1; -fx-background-color: #ffffff; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 5, 0.3, 0, 0);");

        Label jobTitle = new Label(job.getTitle());
        jobTitle.setStyle("-fx-font-weight: bold; -fx-font-size: 20px; -fx-text-fill: #34495e;");

        Label jobDetails = new Label(job.getDetails());
        jobDetails.setWrapText(true);
        jobDetails.setStyle("-fx-font-size: 14px; -fx-text-fill: #7f8c8d;");

        HBox actionButtons = new HBox(10);
        actionButtons.setAlignment(Pos.CENTER_RIGHT);

        Button viewDetailsButton = new Button("View Details");
        styleButton(viewDetailsButton, "#3498db");
        viewDetailsButton.setOnMouseEntered(e -> viewDetailsButton.setStyle("-fx-background-color: #2c81ba; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 8 16; -fx-border-radius: 5; -fx-background-radius: 5;"));
        viewDetailsButton.setOnMouseExited(e -> styleButton(viewDetailsButton, "#3498db"));

        viewDetailsButton.setOnAction(e -> {
            JobDetailsPage jobDetailsPage = new JobDetailsPage(sceneManager, job, dashboardRoot);
            dashboardRoot.setCenter(jobDetailsPage.getView());
        });

        actionButtons.getChildren().add(viewDetailsButton);
        HBox.setHgrow(viewDetailsButton, Priority.ALWAYS);

        jobBox.getChildren().addAll(jobTitle, jobDetails, actionButtons);
        return jobBox;
    }

    /**
     * Generates dummy job listings for display.
     */
    private List<Job> generateJobs() {
        List<Job> jobs = new ArrayList<>();
        jobs.add(new Job("Software Engineer", "TechCorp - Remote - $100,000/year"));
        jobs.add(new Job("Project Manager", "Innovate LLC - Onsite - $80,000/year"));
        jobs.add(new Job("Data Scientist", "AnalyzeAI - Hybrid - $120,000/year"));
        jobs.add(new Job("UX Designer", "DesignIt - Remote - $90,000/year"));
        jobs.add(new Job("Backend Developer", "CodeBase Inc. - Remote - $110,000/year"));
        return jobs;
    }

    /**
     * Styles a button consistently across the application.
     */
    private void styleButton(Button button, String color) {
        button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 8 16; -fx-border-radius: 5; -fx-background-radius: 5;");
    }

    /**
     * Internal Job class to represent job data.
     */
    public static class Job {
        private final String title;
        private final String details;

        public Job(String title, String details) {
            this.title = title;
            this.details = details;
        }

        public String getTitle() {
            return title;
        }

        public String getDetails() {
            return details;
        }
    }
}
