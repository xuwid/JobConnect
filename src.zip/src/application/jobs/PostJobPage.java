package application.jobs;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.util.ArrayList;
import java.util.List;

import application.SceneManager;

public class PostJobPage {
    private final SceneManager sceneManager;
    private final BorderPane dashboardRoot;

    public PostJobPage(SceneManager sceneManager, BorderPane dashboardRoot) {
        this.sceneManager = sceneManager;
        this.dashboardRoot = dashboardRoot;
    }


    public ScrollPane getView() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setStyle("-fx-background-color: #ecf0f1;"); // Light background color

        // Page Title
        Label titleLabel = new Label("Post a New Job");
        titleLabel.setFont(Font.font("Arial", 24));
        titleLabel.setTextFill(Color.web("#34495e")); // Consistent dark blue text

        // Input Sections
        VBox jobTitleSection = createInputSection("Job Title", "Enter Job Title");
        VBox jobDescriptionSection = createInputSection("Job Description", "Enter Job Description", true);
        VBox salarySection = createInputSection("Salary", "Enter Salary");
        VBox locationSection = createInputSection("Location", "Enter Job Location");

        // Requirements Section
        VBox requirementsSection = createRequirementsSection();

        // Post Job Button
        Button postJobButton = createStyledButton("Post Job", "#2980b9");
        postJobButton.setOnAction(e -> {
            String jobTitle = ((TextField) jobTitleSection.getChildren().get(1)).getText();
            String jobDescription = ((TextArea) jobDescriptionSection.getChildren().get(1)).getText();
            String salary = ((TextField) salarySection.getChildren().get(1)).getText();
            String location = ((TextField) locationSection.getChildren().get(1)).getText();

            if (jobTitle.isEmpty() || jobDescription.isEmpty() || salary.isEmpty() || location.isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Incomplete Information", "Please fill all fields before posting the job.");
            } else {
                showAlert(Alert.AlertType.INFORMATION, "Job Posted", "Your job has been posted successfully!");
                dashboardRoot.setCenter(new Label("Job Posted Successfully!")); // Placeholder message
            }
        });

        // Add components to layout
        layout.getChildren().addAll(
                titleLabel,
                jobTitleSection,
                jobDescriptionSection,
                salarySection,
                locationSection,
                requirementsSection,
                postJobButton
        );

        ScrollPane scrollPane = new ScrollPane(layout);
        scrollPane.setFitToWidth(true); // Ensures the content stretches to the full width of the ScrollPane
        scrollPane.setStyle("-fx-background:  #ecf0f1; -fx-padding: 10;"); // Style for the ScrollPane

        return scrollPane;

    }

    /**
     * Creates an input section with a label and a text field or text area.
     */
    private VBox createInputSection(String labelText, String placeholder, boolean isTextArea) {
        Label label = new Label(labelText);
        label.setFont(Font.font("Arial", 16));
        label.setTextFill(Color.web("#34495e"));

        Region inputField;
        if (isTextArea) {
            TextArea textArea = new TextArea();
            textArea.setPromptText(placeholder);
            textArea.setPrefRowCount(5);
            textArea.setStyle("-fx-font-size: 14px; -fx-background-color: #ffffff; -fx-border-color: #bdc3c7; -fx-border-radius: 5; -fx-padding: 10;");
            inputField = textArea;
        } else {
            TextField textField = new TextField();
            textField.setPromptText(placeholder);
            textField.setStyle("-fx-font-size: 14px; -fx-background-color: #ffffff; -fx-border-color: #bdc3c7; -fx-border-radius: 5; -fx-padding: 8;");
            inputField = textField;
        }

        VBox section = new VBox(5, label, inputField);
        section.setPadding(new Insets(10));
        section.setStyle("-fx-background-color: #ffffff; -fx-border-color: #bdc3c7; -fx-border-radius: 5; -fx-background-radius: 5;");
        return section;
    }

    private VBox createInputSection(String labelText, String placeholder) {
        return createInputSection(labelText, placeholder, false);
    }

    /**
     * Creates the job requirements section with a dropdown and added requirements list.
     */
    private VBox createRequirementsSection() {
        Label requirementsLabel = new Label("Job Requirements");
        requirementsLabel.setFont(Font.font("Arial", 16));
        requirementsLabel.setTextFill(Color.web("#34495e"));

        ComboBox<String> requirementsDropdown = new ComboBox<>();
        requirementsDropdown.getItems().addAll("Technical Test", "Aptitude Test", "Coding Challenge", "Communication Test");
        requirementsDropdown.setPromptText("Select Requirement");
        requirementsDropdown.setStyle("-fx-font-size: 14px; -fx-background-color: #ffffff; -fx-border-color: #bdc3c7; -fx-border-radius: 5;");

        List<String> selectedRequirements = new ArrayList<>();
        Label selectedRequirementsLabel = new Label("Added Requirements: None");
        selectedRequirementsLabel.setFont(Font.font("Arial", 14));
        selectedRequirementsLabel.setWrapText(true);

        Button addRequirementButton = createStyledButton("Add Requirement", "#34495e");
        addRequirementButton.setOnAction(e -> {
            String selectedRequirement = requirementsDropdown.getValue();
            if (selectedRequirement != null && !selectedRequirements.contains(selectedRequirement)) {
                selectedRequirements.add(selectedRequirement);
                selectedRequirementsLabel.setText("Added Requirements: " + String.join(", ", selectedRequirements));
            }
        });

        VBox section = new VBox(10, requirementsLabel, requirementsDropdown, addRequirementButton, selectedRequirementsLabel);
        section.setPadding(new Insets(10));
        section.setStyle("-fx-background-color: #ffffff; -fx-border-color: #bdc3c7; -fx-border-radius: 5; -fx-background-radius: 5;");
        return section;
    }

    /**
     * Creates a styled button with consistent theming.
     */
    private Button createStyledButton(String text, String color) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 10 20; -fx-border-radius: 5; -fx-background-radius: 5;");
        button.setOnMouseEntered(e -> button.setStyle("-fx-background-color: #1abc9c; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 10 20; -fx-border-radius: 5; -fx-background-radius: 5;"));
        button.setOnMouseExited(e -> button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 10 20; -fx-border-radius: 5; -fx-background-radius: 5;"));
        return button;
    }

    /**
     * Displays a styled alert dialog.
     */
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
