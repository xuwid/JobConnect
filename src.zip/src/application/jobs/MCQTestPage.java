package application.jobs;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.VBox;
import javafx.scene.layout.BorderPane;

import java.util.ArrayList;
import java.util.List;

import application.SceneManager;

public class MCQTestPage {
    private final SceneManager sceneManager;
    private final BorderPane dashboardRoot;
    private final JobApplicationPage jobApplicationPage;
    private final List<Question> questions;
    private int currentQuestionIndex = 0;
    private int correctAnswers = 0;

    public MCQTestPage(SceneManager sceneManager, BorderPane dashboardRoot, JobApplicationPage jobApplicationPage) {
        this.sceneManager = sceneManager;
        this.dashboardRoot = dashboardRoot;
        this.jobApplicationPage = jobApplicationPage;
        this.questions = generateQuestions();
    }

    public VBox getView() {
        VBox layout = new VBox(20);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));
        layout.setStyle("-fx-background-color: #f4f6f7;");

        // Show the current question
        showQuestion(layout);

        // Add Back Button
        Button backButton = createStyledButton("Back to Job Application", "#e74c3c");
        backButton.setOnAction(e -> {
            // Reset quiz state and return to JobApplicationPage
            currentQuestionIndex = 0;
            correctAnswers = 0;
            dashboardRoot.setCenter(jobApplicationPage.getView());
        });

        layout.getChildren().add(backButton);

        return layout;
    }

    private void showQuestion(VBox layout) {
        layout.getChildren().clear();

        if (currentQuestionIndex < questions.size()) {
            Question question = questions.get(currentQuestionIndex);

            Label questionLabel = new Label(question.getText());
            questionLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #34495e;");

            ToggleGroup optionsGroup = new ToggleGroup();
            VBox optionsBox = new VBox(10);
            optionsBox.setAlignment(Pos.CENTER_LEFT);

            for (String option : question.getOptions()) {
                RadioButton radioButton = new RadioButton(option);
                radioButton.setToggleGroup(optionsGroup);
                radioButton.setStyle("-fx-font-size: 14px; -fx-text-fill: #2c3e50;");
                optionsBox.getChildren().add(radioButton);
            }

            Button nextButton = createStyledButton(currentQuestionIndex == questions.size() - 1 ? "Submit" : "Next", "#3498db");
            nextButton.setOnAction(e -> {
                RadioButton selected = (RadioButton) optionsGroup.getSelectedToggle();
                if (selected != null && selected.getText().equals(question.getAnswer())) {
                    correctAnswers++;
                }
                if (currentQuestionIndex == questions.size() - 1) {
                    submitResults();
                } else {
                    currentQuestionIndex++;
                    showQuestion(layout);
                }
            });

            layout.getChildren().addAll(questionLabel, optionsBox, nextButton);
        }
    }

    /**
     * Submits the test results and navigates back to JobApplicationPage.
     */
    private void submitResults() {
        double score = ((double) correctAnswers / questions.size()) * 100;
        boolean passed = score >= 80.0;

        // Update the JobApplicationPage with the results
        jobApplicationPage.updateView(passed, score);

        // Navigate back to JobApplicationPage
        dashboardRoot.setCenter(jobApplicationPage.getView());
    }

    private List<Question> generateQuestions() {
        List<Question> questions = new ArrayList<>();
        questions.add(new Question("What is Java?", new String[]{"A programming language", "A type of coffee", "An island"}, "A programming language"));
        questions.add(new Question("What does JVM stand for?", new String[]{"Java Virtual Machine", "Java Visual Manager", "Java Volume Marker"}, "Java Virtual Machine"));
        questions.add(new Question("Which company developed Java?", new String[]{"Oracle", "Sun Microsystems", "Microsoft"}, "Sun Microsystems"));
        return questions;
    }

    private static class Question {
        private final String text;
        private final String[] options;
        private final String answer;

        public Question(String text, String[] options, String answer) {
            this.text = text;
            this.options = options;
            this.answer = answer;
        }

        public String getText() {
            return text;
        }

        public String[] getOptions() {
            return options;
        }

        public String getAnswer() {
            return answer;
        }
    }

    private Button createStyledButton(String text, String color) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold; -fx-padding: 10 20; -fx-border-radius: 5; -fx-background-radius: 5;");
        return button;
    }
}
