package application.jobs;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;

import java.util.ArrayList;
import java.util.List;

import application.JobManagementPage;
import application.SceneManager;

public class DeleteJobPage {
    private final SceneManager sceneManager;
    private final BorderPane dashboardRoot;
    private final List<Job> jobs; // Job list to maintain a single source of truth
    private final HBox jobCardsContainer; // For dynamically updating the cards
    private final ListView<Job> jobListView; // For dynamically updating the ListView

    public DeleteJobPage(SceneManager sceneManager, BorderPane dashboardRoot) {
        this.sceneManager = sceneManager;
        this.dashboardRoot = dashboardRoot;
        this.jobs = initializeJobs(); // Initialize the list of jobs
        this.jobCardsContainer = new HBox(20); // Horizontal container for job cards
        this.jobListView = new ListView<>(); // ListView for jobs
    }

    public ScrollPane getView() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setStyle("-fx-background-color: #f9fafc;");

        Label titleLabel = new Label("Delete Jobs");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #34495e;");

        // Create and configure the horizontal scroll pane
        ScrollPane jobCardsScrollPane = createJobCardsScrollPane();

        // Populate the ListView with job items
        jobListView.getItems().addAll(jobs);
        jobListView.setPrefHeight(150);
        jobListView.setStyle("-fx-font-size: 14px;");

        // Delete Button
        Button deleteJobButton = new Button("Delete Selected Job");
        deleteJobButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10;");
        deleteJobButton.setOnAction(e -> deleteSelectedJob());

        // Back Button
        Button backButton = new Button("Back to Manage Options");
        backButton.setStyle("-fx-background-color: #2c3e50; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10;");
        backButton.setOnAction(e -> {
            JobManagementPage jobManagementPage = new JobManagementPage(sceneManager, dashboardRoot);
            dashboardRoot.setCenter(jobManagementPage.getView());
        });

        // Add components to the layout
        layout.getChildren().addAll(titleLabel, jobCardsScrollPane, jobListView, deleteJobButton, backButton);

        ScrollPane scrollPane = new ScrollPane(layout);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent; -fx-focus-color: transparent;");
        return scrollPane;
    }

    private ScrollPane createJobCardsScrollPane() {
        jobCardsContainer.setAlignment(Pos.CENTER_LEFT);
        jobCardsContainer.setPadding(new Insets(20));
        jobCardsContainer.setStyle("-fx-background-color: #ecf0f1; -fx-padding: 20; -fx-border-color: #dce1e3; -fx-border-radius: 10; -fx-background-radius: 10;");

        for (Job job : jobs) {
            VBox jobCard = createJobCard(job);
            jobCardsContainer.getChildren().add(jobCard);
        }

        ScrollPane scrollPane = new ScrollPane(jobCardsContainer);
        scrollPane.setFitToHeight(true);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setStyle("-fx-background: transparent; -fx-border-radius: 10; -fx-background-radius: 10;");

        return scrollPane;
    }

    private VBox createJobCard(Job job) {
        VBox jobCard = new VBox(10);
        jobCard.setPadding(new Insets(10));
        jobCard.setPrefWidth(200);
        jobCard.setStyle("-fx-background-color: white; -fx-border-radius: 10; -fx-border-color: #bdc3c7; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 5, 0.5, 0, 0);");

        Label titleLabel = new Label(job.getTitle());
        titleLabel.setFont(Font.font("Arial", 16));
        titleLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #34495e;");

        Label salaryLabel = new Label("Salary: " + job.getSalary());
        salaryLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #2ecc71;");

        Label locationLabel = new Label("Location: " + job.getLocation());
        locationLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #3498db;");

        Button deleteButton = new Button("Delete");
        deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 14px;");
        deleteButton.setOnAction(e -> deleteJob(job));

        jobCard.getChildren().addAll(titleLabel, salaryLabel, locationLabel, deleteButton);
        return jobCard;
    }

    private void deleteJob(Job job) {
        // Remove from jobs list
        jobs.remove(job);

        // Remove from jobCardsContainer and jobListView
        refreshJobCards();
        jobListView.getItems().remove(job);

        System.out.println("Job deleted: " + job.getTitle());
    }

    private void deleteSelectedJob() {
        Job selectedJob = jobListView.getSelectionModel().getSelectedItem();
        if (selectedJob != null) {
            deleteJob(selectedJob);
        } else {
            System.out.println("Please select a job to delete.");
        }
    }

    private void refreshJobCards() {
        jobCardsContainer.getChildren().clear();
        for (Job job : jobs) {
            VBox jobCard = createJobCard(job);
            jobCardsContainer.getChildren().add(jobCard);
        }
    }

    private List<Job> initializeJobs() {
        List<Job> jobs = new ArrayList<>();
        jobs.add(new Job("Software Engineer", "$100,000", "Remote"));
        jobs.add(new Job("Project Manager", "$80,000", "Onsite"));
        jobs.add(new Job("Data Scientist", "$120,000", "Hybrid"));
        jobs.add(new Job("UX Designer", "$90,000", "Remote"));
        jobs.add(new Job("Frontend Developer", "$95,000", "Onsite"));
        jobs.add(new Job("Backend Developer", "$105,000", "Remote"));
        return jobs;
    }

    public static class Job {
        private final String title;
        private final String salary;
        private final String location;

        public Job(String title, String salary, String location) {
            this.title = title;
            this.salary = salary;
            this.location = location;
        }

        public String getTitle() {
            return title;
        }

        public String getSalary() {
            return salary;
        }

        public String getLocation() {
            return location;
        }

        @Override
        public String toString() {
            return title + " - " + salary + " - " + location;
        }
    }
}
